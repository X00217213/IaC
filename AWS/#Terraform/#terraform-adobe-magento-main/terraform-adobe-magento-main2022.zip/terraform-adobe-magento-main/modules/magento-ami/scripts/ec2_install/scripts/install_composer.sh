#!/bin/bash

sudo wget -O /usr/local/bin/composer https://getcomposer.org/download/latest-stable/composer.phar
sudo chmod +x /usr/local/bin/composer

sudo wget -O /usr/local/bin/n98-magerun2 https://files.magerun.net/n98-magerun2.phar
sudo chmod +x /usr/local/bin/n98-magerun2